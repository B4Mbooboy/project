<?php
include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];

if (!isset($user_id)) {
    header('location:login.php');
}

if (isset($_POST['add_product'])) {
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_FILES['product_image']['name'];

    if (empty($product_image)) {
        $message[] = 'please upload an image!';
    } else {
        $target_dir = "images/";
        $target_file = $target_dir . basename($product_image);
        move_uploaded_file($_FILES['product_image']['tmp_name'], $target_file);

        $insert_product = mysqli_query($conn, "INSERT INTO `products`(name, price, image) VALUES('$product_name', '$product_price', '$product_image')") or die('query failed');

        if ($insert_product) {
            $message[] = 'product added successfully!';
        } else {
            $message[] = 'product could not be added!';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <div class="container">
        <h1 class="heading">Add New Product</h1>

        <?php
        if (isset($message)) {
            foreach ($message as $message) {
                echo '<div class="message" onclick="this.remove();">' . $message . '</div>';
            }
        }
        ?>

        <form action="" method="post" enctype="multipart/form-data">
            <input type="text" name="product_name" placeholder="Product Name" required>
            <input type="text" name="product_price" placeholder="Product Price" required>
            <input type="file" name="product_image" accept="image/*" required>
            <input type="submit" value="Add Product" name="add_product" class="btn">
        </form>
    </div>

</body>

</html>